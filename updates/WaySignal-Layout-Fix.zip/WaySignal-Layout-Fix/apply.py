"""Apply the five native fixes, preserving local edits and backing up originals."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from datetime import datetime

package, project = (Path(p).expanduser().resolve() for p in sys.argv[1:3])
manifest = json.loads((package / 'manifest.json').read_text())
if not (project / 'scripts/run-ios-demo.sh').is_file():
    sys.exit('Open the updated WaySignal project first. Its scripts/run-ios-demo.sh is missing.')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

pending = []
for record in manifest:
    relative = Path(record['path'])
    source = (package / 'payload' / relative).resolve()
    target = (project / relative).resolve()
    if not source.is_relative_to(package / 'payload') or not target.is_relative_to(project):
        sys.exit('Unexpected file path. No changes were applied.')
    if not source.is_file() or digest(source) != record['after']:
        sys.exit('The update is incomplete. Download and extract the ZIP again.')
    if not target.is_file() or digest(target) not in (record['before'], record['after']):
        sys.exit(f'Local changes or an older version found in {relative}. No files were changed. Share this message before continuing.')
    if digest(target) != record['after']:
        pending.append((relative, source, target))

if not pending:
    print('The layout and login fixes are already applied.')
    sys.exit(0)

backup = project.parent / ('WaySignal-Layout-Backup-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
backup.mkdir()
for relative, _, target in pending:
    saved = backup / relative
    saved.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target, saved)

written = []
try:
    for relative, source, target in pending:
        fd, temporary = tempfile.mkstemp(prefix='.waysignal-update-', dir=target.parent)
        os.close(fd)
        try:
            shutil.copy2(source, temporary)
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        written.append((relative, target))
except Exception:
    for relative, target in written:
        shutil.copy2(backup / relative, target)
    raise

print(f'Updated {len(pending)} native files. Backup: {backup}')
print('The app will ask for login. Keep me signed in is off by default.')
