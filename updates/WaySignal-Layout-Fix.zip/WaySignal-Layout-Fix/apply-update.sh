#!/usr/bin/env bash
set -euo pipefail
waysignal_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
waysignal_project="${1:-$HOME/Downloads/waysignal}"
python3 "$waysignal_package/apply.py" "$waysignal_package" "$waysignal_project"
if [[ "${2:-}" != "--apply-only" ]]; then
  bash "$waysignal_project/scripts/run-ios-demo.sh"
fi
