# WaySignal layout and login fix

1. Double-click the downloaded ZIP to extract `WaySignal-Layout-Fix`.
2. In the VS Code terminal, run:

```bash
bash "$HOME/Downloads/WaySignal-Layout-Fix/apply-update.sh"
```

The update checks and backs up five native source files, then builds and opens the iPhone app. Your database and server configuration are preserved. If your project is elsewhere, pass its folder as the first argument. The second argument `--apply-only` skips the build.

The landscape and content fit the screen width. The large orange banner becomes a small **Demo data** badge. Login opens unless you enable **Keep me signed in**. Sign out through Account to switch roles.

Citizen: `citizen@example.com` / `CitizenDemo2026!`

Responder: `worker@example.com` / `WorkerDemo2026!`
